<?php 
class CrudModel extends CI_Model{

/* @author     : Dileep kanjirakkod pazhanan
 *  date        : 29 March 2023
 *  Consid Web Project 
 */

    public function get_data($table)
	{
		$data = $this->db->get($table)->result();

		return $data;
	}

    public function store(){

        $data['name']   = html_escape($this->input->post('name'));
        $data['organization_number']   = html_escape($this->input->post('organization_number'));
        $data['notes']   = html_escape($this->input->post('notes'));
        return $this->db->insert('companies', $data);
    }

    public function update_company($id){

        $data['name']   = html_escape($this->input->post('name'));
        $data['organization_number']   = html_escape($this->input->post('organization_number'));
        $data['notes']   = html_escape($this->input->post('notes'));
        $this->db->where('id', $id);
        return $this->db->update('companies',$data);
       
    }

    public function delete_company($id){
        
    
        $this->db->where('id', $id);
        return $this->db->delete('companies');
       
    }

    public function storedata(){

        $data['name']   = html_escape($this->input->post('name'));
        $data['company_id']   = html_escape($this->input->post('company_id'));
        $data['address']   = html_escape($this->input->post('address'));
        $data['city']   = html_escape($this->input->post('city'));
        $data['zip']   = html_escape($this->input->post('zip'));
        $data['country']   = html_escape($this->input->post('country'));
        $data['longitude']   = html_escape($this->input->post('longitude'));
        $data['latitude']   = html_escape($this->input->post('latitude'));
        
        return $this->db->insert('stores', $data);

    }



    public function update_store($id){

        $data['name']   = html_escape($this->input->post('name'));
        $data['company_id']   = html_escape($this->input->post('company_id'));
        $data['address']   = html_escape($this->input->post('address'));
        $data['city']   = html_escape($this->input->post('city'));
        $data['zip']   = html_escape($this->input->post('zip'));
        $data['country']   = html_escape($this->input->post('country'));
        $data['longitude']   = html_escape($this->input->post('longitude'));
        $data['latitude']   = html_escape($this->input->post('latitude'));
        
        $this->db->where('id', $id);
        return $this->db->update('stores',$data);
       
    }

    public function delete_store($id){
        
        $this->db->where('id', $id);
        return $this->db->delete('stores');
       
    }


   
}

?>