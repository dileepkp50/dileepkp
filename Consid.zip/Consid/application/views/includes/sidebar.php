
<div class="sidenav">

<br><br><br><br>
    <ul>
        <li><a href="<?php echo site_url('OperationController/index');?>">List Company</a></li>
        <li> <a href="<?php echo site_url('StoreoperationController/index');?>">List Store</a></li>
    </ul>
  
 
  
</div>