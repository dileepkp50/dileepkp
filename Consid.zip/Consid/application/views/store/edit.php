<?php
    $stores = $this->db->get_where('stores',array('id'=>$id))->row_array();

?>
<!DOCTYPE html>
<html lang="en">
<head>
   <?php $this->load->view('includes/header'); ?>
   
</head>

<body>
<?php $this->load->view('includes/sidebar'); ?>

<div class="center divElement">
<div class="container">

<div><h5 class="text-dark font-weight-bold my-1 mr-5">Edit Store</h5><br></div>

<form method="post" action="<?php echo site_url('StoreoperationController/editstoredata/'.$stores['id']); ?>">

  <div class="row">

  <div class="col-sm-4">
  <div class="form-group">
    <label for="name">Name</label>
    <input type="text" name="name" value="<?php echo $stores['name']; ?> " class="form-control name" id="name" aria-describedby="nameHelp" placeholder="Enter name" required>
  </div>
</div>

<div class="col-sm-4">
  <div class="form-group">
    <label for="name">Company</label>
          <select class="form-control " name="company_id" id="company_id" required>
                            
                                <?php
                            $companies = $this->db->get('companies')->result_array();
                            foreach($companies as $row2):
                            ?>
                                <option value="" hidden><?php echo ('Select companies'); ?></option>
                            
                                <option value="<?php echo $row2['id'];?>"
                                    <?php if($stores['company_id'] == $row2['id'])echo 'selected';?>>
                             <?php echo $row2['name'];?>
                             </option>
                                <?php
                     endforeach;
                            ?>

          </select>
    
  </div>
    </div>

    <div class="col-sm-4">
  <div class="form-group">
  <label for="address">Address</label>
    <input type="text" name="address" value="<?php echo $stores['address']; ?> "  class="form-control address" id="address" aria-describedby="addressHelp" placeholder="Enter address" required>
  </div>
   </div>

   <div class="col-sm-4">
  <div class="form-group">
  <label for="city">City</label>
    <input type="text" class="form-control city" value="<?php echo $stores['city']; ?> " name="city" id="city" aria-describedby="citysHelp" placeholder="Enter city" required>
  </div>
   </div>

   <div class="col-sm-4">
  <div class="form-group">
  <label for="zip">zip</label>
    <input type="text" class="form-control zip" value="<?php echo $stores['zip']; ?> " name="zip" id="zip" aria-describedby="zipHelp" placeholder="Enter zip" required>
  </div>
   </div>

   <div class="col-sm-4">
  <div class="form-group">
  <label for="country">country</label>
    <input type="text" class="form-control country" value="<?php echo $stores['country']; ?> " name="country" id="country" aria-describedby="countryHelp" placeholder="Enter country" required>
  </div>
   </div>

   <div class="col-sm-4">
  <div class="form-group">
  <label for="longitude">longitude</label>
    <input type="text" class="form-control longitude" value="<?php echo $stores['longitude']; ?> " name="longitude" id="longitude" aria-describedby="longitudeHelp" placeholder="Enter longitude" required>
  </div>
     </div>

     <div class="col-sm-4">
  <div class="form-group">
  <label for="latitude">latitude</label>
    <input type="text" class="form-control latitude"  value="<?php echo $stores['longitude']; ?> " name="latitude" id="latitude" aria-describedby="latitudeHelp" placeholder="Enter latitude" required>
  </div><br>
    </div>

  <button type="submit" class="btn btn-primary">Submit</button>

                    </div>
</form>
  </div>
     </div>


    <?php $this->load->view('includes/footer'); ?>
</body>

</html>