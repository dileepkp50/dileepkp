<!DOCTYPE html>
<html lang="en">
<head>
   <?php $this->load->view('includes/header'); ?>
   <title>Create</title>
</head>
<body>

<?php $this->load->view('includes/sidebar'); ?>
<div class="center divElement">
<div class="container">

<div><h5 class="text-dark font-weight-bold my-1 mr-5">Create Store</h5><br></div>

<form method="post" action="<?php echo site_url('StoreoperationController/store/'); ?>">
<div class="row">

<div class="col-sm-4">
  <div class="form-group">
    <label for="name">Name</label>
    <input type="text" name="name" class="form-control name" id="name" aria-describedby="nameHelp" placeholder="Enter name" required>
  </div>
</div>

<div class="col-sm-4">
  <div class="form-group">
    <label for="name">Company</label>
    <select class="form-control " name="company_id" id="company_id"
                                placeholder="Company" required="required"
       oninvalid="this.setCustomValidity('Choose any value from dropdown If dropdown is empty please add new company')"
       onvalid="this.setCustomValidity('')" >

                                <option value="" hidden><?php echo ('choose companies'); ?></option>
                                <?php
                                                            $companies = $this->db->get('companies')->result_array();
                                                            foreach($companies as $row):
                                                                ?>
                                <option value="<?php echo $row['id'];?>">
                                    <?php echo $row['name'];?>
                                </option>
                                <?php
                                                            endforeach;
                                                        ?>
                            </select>
                            
    
  </div>
     </div>

     <div class="col-sm-4">
  <div class="form-group">
  <label for="address">Address</label>
    <input type="text" name="address" class="form-control address" id="address" aria-describedby="addressHelp" placeholder="Enter address" required>
  </div>
      </div>

  <div class="col-sm-4">
  <div class="form-group">
  <label for="city">City</label>
    <input type="text" class="form-control city" name="city" id="city" aria-describedby="citysHelp" placeholder="Enter city" required>
  </div>
     </div>

     <div class="col-sm-4">
  <div class="form-group">
  <label for="zip">zip</label>
    <input type="text" class="form-control zip" name="zip" id="zip" aria-describedby="zipHelp" placeholder="Enter zip" required>
  </div>
   </div>

  <div class="col-sm-4">
  <div class="form-group">
  <label for="country">country</label>
    <input type="text" class="form-control country" name="country" id="country" aria-describedby="countryHelp" placeholder="Enter country" required>
  </div>
     </div>

     <div class="col-sm-4">
  <div class="form-group">
  <label for="longitude">longitude</label>
    <input type="text" class="form-control longitude" name="longitude" id="longitude" aria-describedby="longitudeHelp" placeholder="Enter longitude">
  </div>
   </div>

   <div class="col-sm-4">
  <div class="form-group">
  <label for="latitude">latitude</label>
    <input type="text" class="form-control latitude" name="latitude" id="latitude" aria-describedby="latitudeHelp" placeholder="Enter latitude">
  </div><br>
     </div>

     <button type="submit" class="btn btn-primary">Submit</button>


    </div>
</form>
     </div>
</div>
    <?php $this->load->view('includes/footer'); ?>
</body>

</html>