<?php
   $stores = $this->db->get_where('stores',array('id'=>$id))->row_array();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view('includes/header'); ?>
</head>


<body>
<?php $this->load->view('includes/sidebar'); ?>

<div class="center divElement">
<div class="container">

<div><h5 class="text-dark font-weight-bold my-1 mr-5">View Store</h5><br></div>


<div class="row">

<div class="form-group col-sm-4">
<label for="Company name"><?php echo('Company name:'); ?></label>
<span class="form-control"><?php $companies = $this->db->get_where('companies' , array('id' => $stores['company_id'] ))->row()->name;
                                                    echo $companies;?></span></div>


<div class="form-group col-sm-4">
<label for="Store  name"><?php echo('Store Name :'); ?></label>
<span class="form-control"><?php echo $stores['name']; ?></span> </div>


<div class="form-group col-sm-4">
<label for="Store  Address"><?php echo('Address :'); ?></label>
<span class="form-control"><?php echo $stores['address']; ?></span> </div>
<input type="text" style="Display: none;" id="address" value="<?php echo $stores['address']; ?>">

<div class="form-group col-sm-4">
<label for="Store  City"><?php echo('City :'); ?></label>
<span class="form-control"><?php echo $stores['city']; ?></span></div>


<div class="form-group col-sm-4">
<label for="Store  Zip"><?php echo('Zip :'); ?></label>
<span class="form-control"><?php echo $stores['zip']; ?></span></div>

<div class="form-group col-sm-4">
<label for="Store Country"><?php echo('Country :'); ?></label>
<span class="form-control"><?php echo $stores['country']; ?></span></div>

<div class="form-group col-sm-4">
<label for="Store Longitude"><?php echo('Longitude :'); ?></label>
<span class="form-control"><?php echo $stores['longitude']; ?></span></div>

<div class="form-group col-sm-4">
<label for="Store Latitude"><?php echo('Latitude :'); ?></label>
<span class="form-control"><?php echo $stores['latitude']; ?></span></div>
</div>




<br>

<input type="text" style="Display: none;" id="longitude" value="<?php echo $stores['longitude']; ?>">
<input type="text" style="Display: none;" id="latitude" value="<?php echo $stores['latitude']; ?>">

 <div id="map" style="height: 300px;"></div>


</div>
</div>

 <script async
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAXaHDVO2mOrsNCwyLQajZjJ4AZGsn_X7w&callback=initMap">
</script>



<script>
 function initMap() {
  var geocoder = new google.maps.Geocoder();

  var address = document.getElementById("address").value;

  geocoder.geocode({'address': address}, function(results, status) {
    if (status === 'OK') {
      var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 16,
        center: results[0].geometry.location
      });
      var marker = new google.maps.Marker({
        map: map,
        position: results[0].geometry.location
      });
    } else {
      alert('Geocode was not successful for the following reason: ' + status);
    }
  });
}


</script>







</body>
</html>





 





