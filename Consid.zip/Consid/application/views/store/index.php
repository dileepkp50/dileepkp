<!DOCTYPE html>
<html lang="en">
<head>
   <?php $this->load->view('includes/header'); ?>
   <title>List</title>
</head>
<body>

   <?php $this->load->view('includes/sidebar'); ?>
   <div class="center divElement">
   <div class="container">
   <div><h5 class="text-dark font-weight-bold my-1 mr-5">List Store</h5><br></div>


   <?php echo $this->session->flashdata('message'); ?>
   
   <a href="<?php echo site_url('StoreoperationController/create');?>" class="btn btn-primary"> Add Store</a>
   <a href="<?php echo site_url('OperationController/index');?>" class="btn btn-primary">List Company</a>

   <div class="table-responsive" style="overflow-x:auto;">
   
   <table  class="table">
    <thead>
        <tr>
            <th>Serial No.</th>
            <th>Name</th>
            <th>Address</th>
            <th>City</th>
            <th>Zip</th>
            <th>Country</th>
            <th>Longitude</th>
            <th>Latitude</th>
        </tr>
    </thead>
    <tbody>

        <?php 
         $count = 1;
         $stores   =   $this->db->get('stores')->result_array();
         foreach($stores as $row):
        ?>
        
        <tr>
           
            <td style="text-align: center;"><?php echo $count++;?></td>
            <td><?php echo $row['name'];?></td>
            <td><?php echo $row['address'];?></td>
            <td><?php echo $row['city'];?></td>
            <td><?php echo $row['zip'];?></td>
            <td><?php echo $row['country'];?></td>
            <td><?php echo $row['longitude'];?></td>
            <td><?php echo $row['latitude'];?></td>
            <td>
            <a href="<?php echo site_url('StoreoperationController/view/'.$row['id']);?>" class="btn btn-primary">View</a>
            <a href="<?php echo site_url('StoreoperationController/edit/'.$row['id']);?>" class="btn btn-primary">Edit</a>
            <a href="<?php echo site_url('StoreoperationController/delete/'.$row['id']);?>" class="btn btn-primary">Delete</a>
            </td>
        </tr>
        
        <?php endforeach;?>
    </tbody>
      </table>

 </div>

         </div>
   </div>
   
    <?php $this->load->view('includes/footer'); ?>
</body>

</html>