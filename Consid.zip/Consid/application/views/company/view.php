<?php
   $companies = $this->db->get_where('companies',array('id'=>$id))->row_array();

?>

<!DOCTYPE html>
<html lang="en">
<head>
<?php $this->load->view('includes/header'); ?>
   
</head>
<body>


<?php $this->load->view('includes/sidebar'); ?>

<div class="center divElement">
<div class="container">

<div><h5 class="text-dark font-weight-bold my-1 mr-5">View Company</h5><br></div>

<div class="row">

<div class="form-group col-sm-6">
<label for="name"><?php echo('name:'); ?></label>
<span class="form-control"><?php echo $companies['name']; ?></span></div>

<div class="col-sm-6">
<label for="Organisation Number"><?php echo('Organisation Number:'); ?></label>
<span class="form-control"><?php echo $companies['organization_number']; ?></span>
</div>

<div class="col-sm-12">
<label for="notes"><?php echo(' Notes:'); ?></label>
<span class="form-control"><?php echo $companies['notes']; ?></span>
</div>

</div>


</div>
</div>
   
</body>
</html>

 