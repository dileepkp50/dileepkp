<?php
    $companies = $this->db->get_where('companies',array('id'=>$id))->row_array();

?>
<!DOCTYPE html>
<html lang="en">
<head>
   <?php $this->load->view('includes/header'); ?>
   <title>Edit</title>
</head>
<body>
<?php $this->load->view('includes/sidebar'); ?>

<div class="center divElement">
<div class="container">

<div><h5 class="text-dark font-weight-bold my-1 mr-5">Edit Company</h5><br></div>

<form method="post" action="<?php echo site_url('OperationController/editdata/'.$companies['id']); ?>">
<div class="row">
<div class="col-sm-6">
  <div class="form-group">
    <label for="name">name</label>
    <input type="text" name="name" value="<?php echo $companies['name']; ?> " class="form-control name" id="name" aria-describedby="nameHelp" placeholder="Enter name" required>
    
  </div>
</div>
<div class="col-sm-6">
  <div class="form-group">
  <label for="organization_number">Organization Number</label>
    <input type="text" value="<?php echo $companies['organization_number']; ?> " name="organization_number" class="form-control organization_number" id="organization_number" aria-describedby="organization_numberHelp" placeholder="Enter organization_number" required>
  </div>
</div>
  <div class="form-group">
  <label for="notes">Notes</label>
    <textarea type="text" class="form-control notes" value="<?php echo $companies['notes']; ?> " name="notes" id="notes" aria-describedby="notesHelp" placeholder="Enter notes">
    <?php echo $companies['notes']; ?> </textarea>
    <br>
  </div>

</div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>


</div>
</div>

    <?php $this->load->view('includes/footer'); ?>
</body>

</html>