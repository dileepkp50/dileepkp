<!DOCTYPE html>
<html lang="en">
<head>
   <?php $this->load->view('includes/header'); ?>
   <title>Create</title>
</head>



<body>
<?php $this->load->view('includes/sidebar'); ?>


<div class="center divElement">
<div class="container">

<div><h5 class="text-dark font-weight-bold my-1 mr-5">Create Company</h5><br></div>

<form method="post" action="<?php echo site_url('OperationController/store/'); ?>">

<div class="row">
  <div class="col-sm-6">
  <div class="form-group">
    <label for="name">	<span class="text-danger">*</span>Name</label>
    <input type="text" name="name" class="form-control name" id="name" aria-describedby="nameHelp" placeholder="Enter name"required>
    
  </div>
  </div>
  
  <div class="col-sm-6">
  <div class="form-group">
  <label for="organization_number">	<span class="text-danger">*</span>Organization Number</label>
    <input type="text" name="organization_number" class="form-control organization_number" id="organization_number" aria-describedby="organization_numberHelp" placeholder="Enter Organization Number" required>
  </div>
  </div>

  <div class="col-sm-12">
  <div class="form-group">
  <label for="notes">Notes</label>
    <textarea type="textarea" rows="4" cols="50"  class="form-control notes" name="notes" id="notes" aria-describedby="notesHelp" placeholder="Enter notes">
    </textarea>
  </div>
  <br>
  </div>

  
  <button type="submit" class="btn btn-primary mr-2">Submit</button>

</div>

</form>

</div>
</div>

    <?php $this->load->view('includes/footer'); ?>
</body>

</html>