<!DOCTYPE html>
<html lang="en">
<head>
   <?php $this->load->view('includes/header'); ?>
   
</head>


<body>
<?php $this->load->view('includes/sidebar'); ?>



<div class="center divElement">
<div class="container">

<div><h5 class="text-dark font-weight-bold my-1 mr-5">List Company</h5><br></div>
    


   <?php echo $this->session->flashdata('message'); ?>

   
   <a href="<?php echo site_url('OperationController/create');?>" class="btn btn-primary"> Add Companies</a>

   <a href="<?php echo site_url('StoreoperationController/index');?>" class="btn btn-primary"> List Store</a>

   <div class="table-responsive" >
   
   <table  class="table">
    <thead>
        <tr>
            <th>Serial No.</th>
            <th>Name</th>
            <th>Organization Number</th>
            <th>Notes</th>
        </tr>
    </thead>
    <tbody>
        <?php 
         $count = 1;
         $companies   =   $this->db->get('companies')->result_array();
         foreach($companies as $row):
        ?>
        <tr>
           
            <td style="text-align: center;"><?php echo $count++;?></td>
            <td><?php echo $row['name'];?></td>
            <td><?php echo $row['organization_number'];?></td>
            <td><?php echo $row['notes'];?></td>
            <td>
            <a href="<?php echo site_url('OperationController/view/'.$row['id']);?>" class="btn btn-primary">View</a>
            <a href="<?php echo site_url('OperationController/edit/'.$row['id']);?>" class="btn btn-primary">Edit</a>
            <a onclick="return confirm('Make sure this company is not added to store')"  href="<?php echo site_url('OperationController/delete/'.$row['id']);?>" class="btn btn-primary">Delete</a>
            </td>
        </tr>
        <?php endforeach;?>
    </tbody>
      </table>

 </div>


   </div>
</div>
   
   
    <?php $this->load->view('includes/footer'); ?>
</body>

</html>