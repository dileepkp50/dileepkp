<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* @author     : Dileep kanjirakkod pazhanan
 *  date        : 29 March 2023
 *  Consid Web Project 
 */


 class StoreoperationController extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('CrudModel');
        
	}

    public function index()
	{
        
		$this->load->view('store/index');
	}

	public function create(){
       
        $this->load->view('store/create');
    }

	public function store(){

        $CrudModel=new CrudModel;  
        
        $CrudModel->storedata();   
        $this->session->set_flashdata('message', '<div class="alert  fade show">Record has been saved successfully.</div>');
        redirect(site_url('StoreoperationController/index'), 'refresh');
    }

	public function view($id){

        $data['id']  = $id;
        $this->load->view('store/view',$data);
    }

	public function edit($id){
       
        $data['id']  = $id;
        $this->load->view('store/edit',$data);
    }
	public function editstoredata($id)
    {
        $CrudModel=new CrudModel;
        $CrudModel->update_store($id);
        $this->session->set_flashdata('message', '<div class="alert  fade show">Record has been Edited successfully.</div>');
        redirect(site_url('StoreoperationController/index'), 'refresh');
     }

	 public function delete($id)
     {
         $CrudModel=new CrudModel;
         $CrudModel->delete_store($id);
         $this->session->set_flashdata('message', '<div class="alert  fade show">Record has been Deleted successfully.</div>');
         redirect(site_url('StoreoperationController/index'), 'refresh');
      }


}

 ?>