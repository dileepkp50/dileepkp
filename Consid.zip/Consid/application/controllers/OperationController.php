<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/* @author     : Dileep kanjirakkod pazhanan
 *  date        : 29 March 2023
 *  Consid Web Project 
 */

class OperationController extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('CrudModel');
        
	}

	public function index()
	{
        
		$this->load->view('company/index');
	}

    public function create(){
       
        $this->load->view('company/create');
    }

    public function view($id){

        $data['id']  = $id;
        $this->load->view('company/view',$data);
    }



    public function store(){

        $CrudModel=new CrudModel;  
        $CrudModel->store();   
        $this->session->set_flashdata('message', '<div class="alert  fade show">Record has been saved successfully.</div>');
        redirect(site_url('OperationController/index'), 'refresh');
    }

    public function edit($id){
       
        $data['id']  = $id;
        $this->load->view('company/edit',$data);
    }

    public function editdata($id)
    {
        $CrudModel=new CrudModel;
        $CrudModel->update_company($id);
        $this->session->set_flashdata('message', '<div class="alert  fade show">Record has been Edited successfully.</div>');
        redirect(site_url('OperationController/index'), 'refresh');
     }

     public function delete($id)
     {
         $CrudModel=new CrudModel;
         $CrudModel->delete_company($id);
         $this->session->set_flashdata('message', '<div class="alert  fade show">Record has been Deleted successfully.</div>');
         redirect(site_url('OperationController/index'), 'refresh');
      }
}